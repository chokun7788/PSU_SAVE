from __future__ import annotations

import json
import os
import re
import sqlite3
import sys
import threading
import urllib.request
from dataclasses import asdict, is_dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_LOG_DIR = ROOT / "data" / "logs"
DEFAULT_SQLITE_PATH = DEFAULT_LOG_DIR / "chat_history.sqlite3"
MAX_WEBHOOK_BYTES = 64 * 1024
WEBHOOK_TIMEOUT_SEC = 2.0
POSTGRES_CONNECT_TIMEOUT_SEC = 2
SESSION_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{15,127}$")
LOCAL_LOG_WRITE_LOCK = threading.Lock()


def _plain(value: Any) -> Any:
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): _plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(item) for item in value]
    return value


def _enabled(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() not in {"0", "false", "no", "off", ""}


def _local_log_dir() -> Path:
    override = os.getenv("PSU_CHAT_LOG_DIR", "").strip()
    return Path(override) if override else DEFAULT_LOG_DIR


def _sqlite_path() -> Path:
    override = os.getenv("PSU_CHAT_LOG_SQLITE_PATH", "").strip()
    return Path(override) if override else DEFAULT_SQLITE_PATH


def is_valid_session_id(value: str) -> bool:
    """Accept opaque browser session identifiers, but never use arbitrary SQL input."""
    return bool(SESSION_ID_PATTERN.fullmatch(str(value or "").strip()))


def read_sqlite_session_history(session_id: str, *, limit: int = 500) -> list[dict[str, Any]]:
    """Read the local conversation transcript in display order.

    This reader is deliberately SQLite-only. The local-owner package keeps its
    history on the same machine, while a future multi-user deployment should
    expose an authenticated history service backed by Postgres instead.
    """
    normalized_session_id = str(session_id or "").strip()
    if not is_valid_session_id(normalized_session_id):
        raise ValueError("invalid_session_id")

    db_path = _sqlite_path()
    if not db_path.exists():
        return []

    safe_limit = max(1, min(int(limit), 500))
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """
            SELECT id, role, content, resolved_question, route_category, route_intent,
                   mode, confidence, latency_sec, sources_json, metadata_json, created_at
            FROM chat_messages
            WHERE session_id = ?
            ORDER BY id DESC
            LIMIT ?
            """,
            (normalized_session_id, safe_limit),
        ).fetchall()
    except sqlite3.OperationalError:
        # The database can be absent or created by an older runtime during the
        # first launch. A blank transcript is safer than turning refresh into an error.
        return []
    finally:
        conn.close()

    history: list[dict[str, Any]] = []
    for row in reversed(rows):
        try:
            metadata = json.loads(row["metadata_json"] or "{}")
        except (TypeError, ValueError):
            metadata = {}
        try:
            sources = json.loads(row["sources_json"] or "[]")
        except (TypeError, ValueError):
            sources = []
        history.append({
            "id": int(row["id"]),
            "role": str(row["role"] or "system"),
            "content": str(row["content"] or ""),
            "resolved_question": str(row["resolved_question"] or ""),
            "route_category": str(row["route_category"] or ""),
            "route_intent": str(row["route_intent"] or ""),
            "mode": str(row["mode"] or ""),
            "confidence": row["confidence"],
            "latency_sec": row["latency_sec"],
            "sources": sources if isinstance(sources, list) else [],
            "metadata": metadata if isinstance(metadata, dict) else {},
            "created_at": str(row["created_at"] or ""),
        })
    return history


def _postgres_url() -> str:
    for name in ("DATABASE_URL", "POSTGRES_URL", "POSTGRES_PRISMA_URL", "POSTGRES_URL_NON_POOLING"):
        value = os.getenv(name, "").strip()
        if value:
            return value
    return ""


def _write_local_jsonl(record: dict[str, Any]) -> None:
    log_dir = _local_log_dir()
    log_dir.mkdir(parents=True, exist_ok=True)
    today = datetime.now(UTC).astimezone().strftime("%Y-%m-%d")
    log_path = log_dir / f"web_chat_{today}.jsonl"
    with log_path.open("a", encoding="utf-8") as file:
        file.write(json.dumps(record, ensure_ascii=False, default=_plain) + "\n")


def _init_sqlite(conn: sqlite3.Connection) -> None:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS chat_sessions (
      session_id TEXT PRIMARY KEY,
      session_number INTEGER,
      channel TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      last_route_category TEXT,
      last_route_intent TEXT,
      last_mode TEXT,
      message_count INTEGER NOT NULL DEFAULT 0
    )
    """)
    session_columns = {str(row[1]) for row in conn.execute("PRAGMA table_info(chat_sessions)")}
    if "session_number" not in session_columns:
        conn.execute("ALTER TABLE chat_sessions ADD COLUMN session_number INTEGER")
    conn.execute("""
    CREATE UNIQUE INDEX IF NOT EXISTS idx_chat_sessions_session_number
    ON chat_sessions(session_number)
    """)
    conn.execute("""
    CREATE TABLE IF NOT EXISTS chat_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT NOT NULL,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      resolved_question TEXT,
      route_category TEXT,
      route_intent TEXT,
      mode TEXT,
      confidence REAL,
      latency_sec REAL,
      sources_json TEXT,
      metadata_json TEXT,
      created_at TEXT NOT NULL
    )
    """)
    conn.execute("""
    CREATE INDEX IF NOT EXISTS idx_chat_messages_session_id
    ON chat_messages(session_id, id)
    """)


def _insert_sqlite_message(conn: sqlite3.Connection, record: dict[str, Any], role: str, content: str) -> None:
    conn.execute(
        """
        INSERT INTO chat_messages (
          session_id, role, content, resolved_question, route_category, route_intent,
          mode, confidence, latency_sec, sources_json, metadata_json, created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            str(record.get("client_session_id") or "anonymous").strip() or "anonymous",
            role,
            content,
            str(record.get("resolved_question") or ""),
            str(record.get("route_category") or ""),
            str(record.get("route_intent") or ""),
            str(record.get("mode") or ""),
            record.get("confidence") if isinstance(record.get("confidence"), (int, float)) else None,
            record.get("latency_sec") if isinstance(record.get("latency_sec"), (int, float)) else None,
            json.dumps(_plain(record.get("sources") or []), ensure_ascii=False),
            json.dumps(_plain({
                "request_id": record.get("request_id"),
                "exchange_id": record.get("exchange_id"),
                "schema_version": record.get("schema_version"),
                "context_resolution": record.get("context_resolution"),
                "query_debug": record.get("query_debug"),
                "decision_artifact": record.get("decision_artifact"),
                "universal_intent": record.get("universal_intent"),
                "language": record.get("language"),
                "input_recovery": record.get("input_recovery"),
                "recent_history_count": record.get("recent_history_count"),
                "experimental": record.get("experimental"),
                "validation_ok": record.get("validation_ok"),
                "error": record.get("error"),
                "wall_sec": record.get("wall_sec"),
                "timing_status": record.get("timing_status"),
                "timed_out": record.get("timed_out"),
                "timeout_stage": record.get("timeout_stage"),
                "worker_id": record.get("worker_id"),
            }), ensure_ascii=False),
            str(record.get("timestamp") or datetime.now(UTC).isoformat()),
        ),
    )


def _write_sqlite(record: dict[str, Any]) -> int:
    db_path = _sqlite_path()
    db_path.parent.mkdir(parents=True, exist_ok=True)

    session_id = str(record.get("client_session_id") or "anonymous").strip() or "anonymous"
    timestamp = str(record.get("timestamp") or datetime.now(UTC).isoformat())
    conn = sqlite3.connect(db_path, timeout=15.0)
    try:
        _init_sqlite(conn)
        conn.commit()
        # This write transaction serializes session-number allocation. It
        # prevents two simultaneous questions from receiving the same visible
        # Session # while SQLite keeps message IDs strictly ordered.
        conn.execute("BEGIN IMMEDIATE")
        existing = conn.execute(
            "SELECT session_number FROM chat_sessions WHERE session_id = ?",
            (session_id,),
        ).fetchone()
        if existing is None:
            session_number = int(conn.execute(
                "SELECT COALESCE(MAX(session_number), 0) + 1 FROM chat_sessions"
            ).fetchone()[0])
            conn.execute(
                """
                INSERT INTO chat_sessions (
                  session_id, session_number, channel, created_at, updated_at,
                  last_route_category, last_route_intent, last_mode, message_count
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
                """,
                (
                    session_id,
                    session_number,
                    str(record.get("channel") or ""),
                    timestamp,
                    timestamp,
                    str(record.get("route_category") or ""),
                    str(record.get("route_intent") or ""),
                    str(record.get("mode") or ""),
                ),
            )
        else:
            session_number = int(existing[0] or 0)
            if session_number <= 0:
                session_number = int(conn.execute(
                    "SELECT COALESCE(MAX(session_number), 0) + 1 FROM chat_sessions"
                ).fetchone()[0])
            conn.execute(
                """
                UPDATE chat_sessions
                SET session_number = ?, updated_at = ?, channel = ?,
                    last_route_category = ?, last_route_intent = ?, last_mode = ?
                WHERE session_id = ?
                """,
                (
                    session_number,
                    timestamp,
                    str(record.get("channel") or ""),
                    str(record.get("route_category") or ""),
                    str(record.get("route_intent") or ""),
                    str(record.get("mode") or ""),
                    session_id,
                ),
            )

        question = str(record.get("question") or "").strip()
        answer = str(record.get("answer") or "").strip()
        error = str(record.get("error") or "").strip()
        inserted = 0
        if question:
            _insert_sqlite_message(conn, record, "user", question)
            inserted += 1
        if answer:
            _insert_sqlite_message(conn, record, "assistant", answer)
            inserted += 1
        if error and not answer:
            _insert_sqlite_message(conn, record, "system", error)
            inserted += 1
        if inserted:
            conn.execute(
                "UPDATE chat_sessions SET message_count = message_count + ? WHERE session_id = ?",
                (inserted, session_id),
            )
        conn.commit()
        return session_number
    finally:
        conn.close()


def _postgres_connect(url: str):
    try:
        import psycopg  # type: ignore
    except ImportError as exc:  # pragma: no cover - depends on deploy env
        raise RuntimeError("psycopg is required for Postgres logging; install psycopg[binary]") from exc
    return psycopg.connect(url, autocommit=False, connect_timeout=POSTGRES_CONNECT_TIMEOUT_SEC)


def _init_postgres(conn: Any) -> None:
    with conn.cursor() as cur:
        cur.execute("""
        CREATE TABLE IF NOT EXISTS chat_sessions (
          session_id TEXT PRIMARY KEY,
          channel TEXT,
          created_at TIMESTAMPTZ NOT NULL,
          updated_at TIMESTAMPTZ NOT NULL,
          last_route_category TEXT,
          last_route_intent TEXT,
          last_mode TEXT,
          message_count INTEGER NOT NULL DEFAULT 0
        )
        """)
        cur.execute("""
        CREATE TABLE IF NOT EXISTS chat_messages (
          id BIGSERIAL PRIMARY KEY,
          session_id TEXT NOT NULL REFERENCES chat_sessions(session_id) ON DELETE CASCADE,
          role TEXT NOT NULL,
          content TEXT NOT NULL,
          resolved_question TEXT,
          route_category TEXT,
          route_intent TEXT,
          mode TEXT,
          confidence DOUBLE PRECISION,
          latency_sec DOUBLE PRECISION,
          sources_json TEXT,
          metadata_json TEXT,
          created_at TIMESTAMPTZ NOT NULL
        )
        """)
        cur.execute("""
        CREATE INDEX IF NOT EXISTS idx_chat_messages_session_id
        ON chat_messages(session_id, id)
        """)


def _insert_postgres_message(conn: Any, record: dict[str, Any], role: str, content: str) -> None:
    session_id = str(record.get("client_session_id") or "anonymous").strip() or "anonymous"
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO chat_messages (
              session_id, role, content, resolved_question, route_category, route_intent,
              mode, confidence, latency_sec, sources_json, metadata_json, created_at
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                session_id,
                role,
                content,
                str(record.get("resolved_question") or ""),
                str(record.get("route_category") or ""),
                str(record.get("route_intent") or ""),
                str(record.get("mode") or ""),
                record.get("confidence") if isinstance(record.get("confidence"), (int, float)) else None,
                record.get("latency_sec") if isinstance(record.get("latency_sec"), (int, float)) else None,
                json.dumps(_plain(record.get("sources") or []), ensure_ascii=False),
                json.dumps(_plain({
                "request_id": record.get("request_id"),
                "exchange_id": record.get("exchange_id"),
                "schema_version": record.get("schema_version"),
                    "context_resolution": record.get("context_resolution"),
                    "query_debug": record.get("query_debug"),
                    "decision_artifact": record.get("decision_artifact"),
                    "universal_intent": record.get("universal_intent"),
                    "language": record.get("language"),
                    "input_recovery": record.get("input_recovery"),
                    "recent_history_count": record.get("recent_history_count"),
                    "experimental": record.get("experimental"),
                    "validation_ok": record.get("validation_ok"),
                    "error": record.get("error"),
                    "wall_sec": record.get("wall_sec"),
                    "timing_status": record.get("timing_status"),
                    "timed_out": record.get("timed_out"),
                    "timeout_stage": record.get("timeout_stage"),
                    "worker_id": record.get("worker_id"),
                }), ensure_ascii=False),
                str(record.get("timestamp") or datetime.now(UTC).isoformat()),
            ),
        )


def _write_postgres(record: dict[str, Any]) -> None:
    url = _postgres_url()
    if not url:
        return

    session_id = str(record.get("client_session_id") or "anonymous").strip() or "anonymous"
    timestamp = str(record.get("timestamp") or datetime.now(UTC).isoformat())
    conn = _postgres_connect(url)
    try:
        _init_postgres(conn)
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO chat_sessions (
                  session_id, channel, created_at, updated_at,
                  last_route_category, last_route_intent, last_mode, message_count
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, 0)
                ON CONFLICT(session_id) DO UPDATE SET
                  updated_at = EXCLUDED.updated_at,
                  channel = EXCLUDED.channel,
                  last_route_category = EXCLUDED.last_route_category,
                  last_route_intent = EXCLUDED.last_route_intent,
                  last_mode = EXCLUDED.last_mode
                """,
                (
                    session_id,
                    str(record.get("channel") or ""),
                    timestamp,
                    timestamp,
                    str(record.get("route_category") or ""),
                    str(record.get("route_intent") or ""),
                    str(record.get("mode") or ""),
                ),
            )

        question = str(record.get("question") or "").strip()
        answer = str(record.get("answer") or "").strip()
        error = str(record.get("error") or "").strip()
        inserted = 0
        if question:
            _insert_postgres_message(conn, record, "user", question)
            inserted += 1
        if answer:
            _insert_postgres_message(conn, record, "assistant", answer)
            inserted += 1
        if error and not answer:
            _insert_postgres_message(conn, record, "system", error)
            inserted += 1
        if inserted:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE chat_sessions SET message_count = message_count + %s WHERE session_id = %s",
                    (inserted, session_id),
                )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _write_stdout(record: dict[str, Any]) -> None:
    payload = {"event": "psu_chat_log", **record}
    print(json.dumps(payload, ensure_ascii=False, default=_plain), file=sys.stdout, flush=True)


def _post_webhook(record: dict[str, Any]) -> None:
    url = os.getenv("PSU_CHAT_LOG_WEBHOOK_URL", "").strip()
    if not url:
        return
    payload = json.dumps(record, ensure_ascii=False, default=_plain).encode("utf-8")
    if len(payload) > MAX_WEBHOOK_BYTES:
        trimmed = dict(record)
        answer = str(trimmed.get("answer") or "")
        trimmed["answer"] = answer[:2000] + ("..." if len(answer) > 2000 else "")
        payload = json.dumps(trimmed, ensure_ascii=False, default=_plain).encode("utf-8")

    headers = {"Content-Type": "application/json; charset=utf-8"}
    token = os.getenv("PSU_CHAT_LOG_WEBHOOK_TOKEN", "").strip()
    if token:
        headers["Authorization"] = f"Bearer {token}"

    request = urllib.request.Request(url, data=payload, headers=headers, method="POST")
    with urllib.request.urlopen(request, timeout=WEBHOOK_TIMEOUT_SEC) as response:
        response.read(256)


def write_chat_log(record: dict[str, Any]) -> dict[str, Any]:
    """Write a chat log record to configured sinks.

    Local JSONL is useful for local development. stdout/webhook are better for
    serverless production where writing to the project filesystem is not durable.
    Logging failures are returned as metadata and must not break chat answers.
    """
    enriched = {
        "timestamp": datetime.now(UTC).isoformat(),
        "schema_version": 1,
        **record,
    }
    sinks: dict[str, Any] = {}

    sqlite_enabled = _enabled("PSU_CHAT_LOG_SQLITE", default=True)
    jsonl_enabled = _enabled("PSU_CHAT_LOG_LOCAL_JSONL", default=True)
    if sqlite_enabled or jsonl_enabled:
        # Chat requests are logged from lightweight background threads. One
        # process-local lock keeps each JSONL exchange as one intact line and
        # pairs it with the SQLite transaction without interleaving writes.
        with LOCAL_LOG_WRITE_LOCK:
            if sqlite_enabled:
                try:
                    enriched["session_number"] = _write_sqlite(enriched)
                    sinks["sqlite"] = str(_sqlite_path())
                except Exception as exc:  # pragma: no cover
                    sinks["sqlite_error"] = repr(exc)
            if jsonl_enabled:
                try:
                    _write_local_jsonl(enriched)
                    sinks["local_jsonl"] = True
                except Exception as exc:  # pragma: no cover - defensive runtime guard
                    sinks["local_jsonl_error"] = repr(exc)

    if _enabled("PSU_CHAT_LOG_POSTGRES", default=bool(_postgres_url())) and _postgres_url():
        try:
            _write_postgres(enriched)
            sinks["postgres"] = True
        except Exception as exc:  # pragma: no cover
            sinks["postgres_error"] = repr(exc)

    if _enabled("PSU_CHAT_LOG_STDOUT", default=False):
        try:
            _write_stdout(enriched)
            sinks["stdout"] = True
        except Exception as exc:  # pragma: no cover
            sinks["stdout_error"] = repr(exc)

    if os.getenv("PSU_CHAT_LOG_WEBHOOK_URL", "").strip():
        try:
            _post_webhook(enriched)
            sinks["webhook"] = True
        except Exception as exc:  # pragma: no cover
            sinks["webhook_error"] = repr(exc)

    return sinks
